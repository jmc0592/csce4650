#include "List.h"

List::List(){
	head = NULL;
	current = NULL;

}