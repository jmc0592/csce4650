#include "Record.h"

Record::Record(string k){
	key = k;
	after = NULL;
}